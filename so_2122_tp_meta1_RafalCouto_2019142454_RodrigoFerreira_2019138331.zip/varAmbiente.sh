#source varAmbiente.sh (Define as variáveis)

export MAXCLIENTES=10
export MAXMEDICOS=10
export MAXESPECIALIDADES=6
export MAXLUGARESFILA=5


